import React, { Component } from 'react';

import Dropdown from './DROPDOWN/Dropdown';
import Navbar from './DROPDOWN/Navbar';
class AppBar extends Component {
    
    render() { 
        return (<div ><Navbar/></div>);
    }
}
 
export default AppBar;