import React, { Component } from 'react';

import Dropdown from './admin/DROPDOWN/Dropdown';
import Navbar from './admin/DROPDOWN/AdminNavbar';
class AdminAppBar extends Component {
    
    render() { 
        return (<div ><Navbar/></div>);
    }
}
 
export default AdminAppBar;